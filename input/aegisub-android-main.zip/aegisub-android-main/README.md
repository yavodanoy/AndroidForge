# Aegisub Android

> Android 平台上最接近桌面 Aegisub 体验的专业级字幕编辑器。

[![Status](https://img.shields.io/badge/status-Phase%208%20(Desktop%20Replication)-blue)](ROADMAP.md)
[![License](https://img.shields.io/badge/license-Aegisub%20BSD-green)](LICENCE)
[![Platform](https://img.shields.io/badge/platform-Android%208.0%2B-3DDC84)]()
[![Language](https://img.shields.io/badge/language-Kotlin-7F52FF)]()

本项目参考并部分移植自 [Aegisub](https://github.com/TypesettingTools/Aegisub)（跨平台高级字幕编辑器，BSD 许可），目标是把桌面端的核心字幕工程能力完整带到 Android：字幕/样式/标签/时间轴编辑、Karaoke、打轴辅助，并充分利用 Android 平台能力（响应式布局、Media3、外接键鼠、DeX）。

**作者 / 维护**：伤感咩吖

---

## ✨ 特性

**已交付（Phase 0–7 核心闭环 + Phase 8 桌面端复刻）**

- **多格式**：ASS / SSA / SRT / LRC / TXT，导入导出双向，自动识别与统一格式。
- **无损精度**：内部以微秒存储时间，ASS 厘秒 / 毫秒 / 自动三档导出精度，往返零精度损失。
- **LRC 全格式**：支持 `[mm:ss.xx]` `[mm:ss.xxx]` `[mm:ss:xx]` `[mm:ss:xxx]` 及混合格式文件。
- **专业编辑**：撤销重做（CoW 快照，有界内存治理）、历史版本恢复、防抖自动保存、查找替换（正则）、**行级操作（复制/删除/插入/分割/合并/上下移）**、批量操作（时间偏移 / 删除空行 / 样式批量替换）、**排序（起止/样式/演员/效果/文本/层）、帧率转换**。
- **脚本属性**：编辑 Title / PlayResX/Y / WrapStyle / ScaledBorderAndShadow / Collisions / Timer。
- **样式编辑器**：名称 / 字体 / 字号 / 四色 RGBA / 粗斜下划删除线 / 九宫对齐 / L-R-V 边距 / 描边阴影 / 边框类型 / 缩放间距旋转 / 编码，全字段编辑。
- **助手工具**：**样式助手**（逐行套样式）、**翻译助手**（原文→Name/译文→Text）、**Karaoke 音节生成**（{\k}/{\kf}，按词/按字，时长均匀分配）。
- **可视化打字**：视频画面拖拽设 {\pos}（脚本坐标系映射，松手提交单撤销点）、{\fr} 旋转滑块。
- **多媒体**：视频预览（Media3/ExoPlayer）、音频波形 + 频谱热图双视图（radix-2 FFT）、逐帧（FPS 检测）、打轴辅助（WASD 踩点 + 拖拽手柄 + 帧级微调）。
- **响应式**：手机 / 平板 / 横竖屏，按用户布局偏好或屏宽断点分派 compact/expanded。
- **首选项**：主题 / 导出精度 / 布局，DataStore 持久化。
- **超大文件**：虚拟列表 + 结构共享撤销引擎，常规规模流畅可编辑。

完整功能比对（已实现 / 部分 / 缺口）见 [docs/COMPARISON.md](docs/COMPARISON.md)。

**进行中（Phase 9 第二轮复刻）**：字幕网格多选批量、Karaoke 交互式计时、{\move}/{\fad}/{\clip} 可视化、关键帧吸附、时间后处理（去重叠/lead-in-out）、分辨率重采样器。

**远期预留**：Lua Automation、插件系统、libass JNI 精确渲染、AI 辅助字幕、持久向量（bit-partitioned trie）支撑 10 万行级。

## 🏗️ 架构

多模块 Gradle，业务逻辑全部下沉到 `:core:*`，UI 层纯展示（黑盒架构）：

| 模块 | 职责 | 阶段 |
|---|---|---|
| `:core:domain` | 纯 Kotlin/JVM：时间/数据模型/tokenizer/格式编解码/撤销引擎 | **Phase 0** |
| `:core:data` | Room + DataStore：项目管理 / 自动保存 / 历史版本 | Phase 1 |
| `:core:media` | Media3 / ExoPlayer + 音频波形提取 | Phase 3-4 |
| `:core:ass-render` | libass JNI 桥（预留） | 远期 |
| `:feature:*` | Compose UI：字幕列表 / 编辑底栏 / 双栏布局（`:feature:editor`）/ 视频预览+字幕叠加（`:feature:preview`） | Phase 2-3 |
| `:app` | 应用入口 + 导航 + Hilt DI + 响应式布局 | Phase 1+ |

详见 [核心设计 Spec](docs/superpowers/specs/2026-06-13-aegisub-android-core-design.md) 与 [Roadmap](ROADMAP.md)。

## 🧱 技术栈

Kotlin · Jetpack Compose · Material3 · MVVM · Coroutines · Flow · Room · DataStore · Media3 / ExoPlayer · Hilt · `kotlinx.collections.immutable`

## 📐 平板布局

```
┌──────────┬───────────────────────┬──────────────┐
│ 字幕列表  │      视频预览          │  属性编辑器   │
│          ├───────────────────────┤              │
│          │      时间轴 / 波形      │              │
└──────────┴───────────────────────┴──────────────┘
```

## 📜 许可证

[BSD (Aegisub License)](LICENCE)。参考 / 移植自 Aegisub 的文件保留其版权声明；原创代码署名伤感咩吖。
